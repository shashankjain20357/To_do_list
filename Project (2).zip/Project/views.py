from app import app , db
from flask import render_template , request , redirect
from models import Task
from datetime import datetime
import os

@app.route('/')
def dashboard():
    tasks = Task.query.all()
    return render_template('dashboard.html' , tasks = tasks)


@app.route("/add-task", methods=["GET", "POST"])
def add_task():
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        date = request.form.get('date')

       
        date = datetime.strptime(date, '%Y-%m-%d')  

        new_task = Task(title=title, description=description, due_date=date) 
        
        try:
            db.session.add(new_task)
            db.session.commit()
            return redirect("/")
        except Exception as e:
            db.session.rollback()
            return f"An error occurred: {str(e)}"

    return render_template("add_task.html")



@app.route("/mark_task/<int:task_id>/<int:completed>", methods=["POST"])
def mark_task(task_id, completed):
    task = Task.query.get(task_id)
    if task:
        task.completed = bool(completed)
        db.session.commit()
    return redirect("/")


@app.route("/delete_task/<int:task_id>", methods=["POST"])
def delete_task(task_id):
    task = Task.query.get(task_id)
    if task:
        db.session.delete(task)
        db.session.commit()
    return redirect("/")

@app.route("/save_tasks", methods=["POST"])
def save_tasks():
    tasks = Task.query.all()
    task_data = []

    for task in tasks:
        task_info = {
            "Title": task.title,
            "Description": task.description,
            "Date": task.due_date.strftime('%Y-%m-%d') if task.due_date else '',
            "Completed": "True" if task.completed else "False"
        }

        task_lines = [f"{header}: {value}" for header, value in task_info.items()]
        task_data.append("\n".join(task_lines) + "\n")

    file_path = os.path.join(app.root_path, "tasks.txt")

    with open(file_path, "w") as file:
        file.writelines(task_data)

    return "Tasks Saved Successfully"

@app.route('/upload-tasks', methods=['GET', 'POST'])
def upload_tasks():
    if request.method == 'POST':
        uploaded_file = request.files['file']

        if uploaded_file and uploaded_file.filename.endswith('.txt'):
            tasks = []
            file_content = uploaded_file.read().decode('utf-8')
            task_texts = file_content.strip().split('\n\n')

            for task_text in task_texts:
                task_info = extract_task_info_from_text(task_text)
                due_date = task_info.get('Date', '')
                due_date = datetime.strptime(due_date, '%Y-%m-%d') if due_date else None
                task = Task(
                    title=task_info.get('Title', ''),
                    description=task_info.get('Description', ''),
                    due_date=due_date,
                    completed=task_info.get('Completed', 'False') == 'True'
                )
                tasks.append(task)

            db.session.add_all(tasks)
            db.session.commit()

            return "Tasks uploaded successfully"

    return redirect('/')


def extract_task_info_from_text(text):
    lines = text.strip().split('\n')
    task_info = {}
    for line in lines:
        header, value = map(str.strip, line.split(':', 1) if ':' in line else (line, ''))
        task_info[header] = value
    return task_info
